package com.theboys.wildberries;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WildberriesApplication {

	public static void main(String[] args) {
		SpringApplication.run(WildberriesApplication.class, args);
	}

}
