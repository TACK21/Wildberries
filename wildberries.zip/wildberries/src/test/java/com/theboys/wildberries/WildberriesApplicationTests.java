package com.theboys.wildberries;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WildberriesApplicationTests {

	@Test
	void contextLoads() {
	}

}
